#include "stm32f4xx_hal.h"
#include "sounds.h"
#include <math.h>

float globalTime = 0;

// used to generate correct output of different waves
float w(float freq) {
	return freq/F_SAMPLE * 2.0f * PI;
}

float time(float freq) {
	return (int)globalTime%(int)(F_SAMPLE/freq);
}

// used to generate sound of different waves
float generateSinWave(float freq) {
	float point = time(freq) * w(freq);

	return sinf(point) + 1;
}

float generateSquareWave(float freq) {
	float point = time(freq) * w(freq);

	return ((sinf(point) >= 0.5f)? 1: -1) + 1;
}

float generateTriangleWave(float freq) {
	float point = time(freq) * w(freq);

	return asinf(sinf(point)) * (2.0f / PI) + 1;
}

float generateSawAnalogueWave(float freq) {
	float point= time(freq) * w(freq);

	float output = 0.0f;

	for(float i = 1.0f; i < 50.0f; i++) {
		output += (sinf(i * point)) / i;
	}

	return output * (2.0f / PI) + 1;
}

float osc(float freq, OSC_TYPE type) {
	switch(type) {
	case SIN:
		return generateSinWave(freq);
		break;
	case SQUARE:
		return generateSquareWave(freq);
		break;
	case TRIANGLE:
		return generateTriangleWave(freq);
		break;
	case SAW_AN:
		return generateSawAnalogueWave(freq);
		break;
	default:
		return 0;
	}
}

float synthesizeSound(float freq) {
	float wave = osc(freq, SQUARE);

	return wave;
}


/* We generate the array of sounds */
float generateWaves(Note s) {
	switch(s) {
	case C:
		return synthesizeSound(1.0f);
		break;
	case D:
		return synthesizeSound(293.66f);
		break;
	case E:
		return synthesizeSound(329.63f);
		break;
	case F:
		return synthesizeSound(349.23f);
		break;
	case G:
		return synthesizeSound(392.0f);
		break;
	case A:
		return synthesizeSound(440.0f);
		break;
	case B:
		return synthesizeSound(493.88f);
		break;
	case C2:
		return synthesizeSound(523.25f);
		break;
	default:
		return 0;
		break;
	}
}
